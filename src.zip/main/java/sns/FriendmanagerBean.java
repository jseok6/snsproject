package sns;

public class FriendmanagerBean {
	private int friendIndex;
	private String userEmail;
	private String friendEmail;
	private int friendSign;
	public int getFriendIndex() {
		return friendIndex;
	}
	public void setFriendIndex(int friendIndex) {
		this.friendIndex = friendIndex;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getFriendEmail() {
		return friendEmail;
	}
	public void setFriendEmail(String friendEmail) {
		this.friendEmail = friendEmail;
	}
	public int getFriendSign() {
		return friendSign;
	}
	public void setFriendSign(int friendSign) {
		this.friendSign = friendSign;
	}
	
}

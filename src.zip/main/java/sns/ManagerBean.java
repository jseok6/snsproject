package sns;

public class ManagerBean {
	private String mgEmail;
	private String pwd;
	public String getMgEmail() {
		return mgEmail;
	}
	public void setMgEmail(String mgEmail) {
		this.mgEmail = mgEmail;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
}

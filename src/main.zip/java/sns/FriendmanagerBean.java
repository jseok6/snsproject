package sns;

public class FriendmanagerBean {
	private String friendIndex;
	public String getFriendIndex() {
		return friendIndex;
	}
	public void setFriendIndex(String friendIndex) {
		this.friendIndex = friendIndex;
	}
	private String userEmail;
	private String friendEmail;
	private int friendSign;
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getFriendEmail() {
		return friendEmail;
	}
	public void setFriendEmail(String friendEmail) {
		this.friendEmail = friendEmail;
	}
	public int getFriendSign() {
		return friendSign;
	}
	public void setFriendSign(int friendSign) {
		this.friendSign = friendSign;
	}
	
}
